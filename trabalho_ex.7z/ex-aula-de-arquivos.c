#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estruturas.h"
#include <locale.h>

void converter_csv(char *arquivo){
    printf("Converte para CSV %s\n", arquivo);
    
    FILE *arq_csv, *arq_txt;
    char linha[MAX_LINE_LENGTH];

    Registro dados;
    //abre o arquivo txt
    arq_txt = fopen("dados.txt", "r");
    if (arq_txt == NULL)
    {
        printf("Erro ao abrir o arquivo TXT");
        return 1;
    }
    //cria ou sobrescreve o CSV
    arq_csv = fopen("dados.csv", "w");
    if (arq_csv == NULL)
    {
        printf("Erro ao criar o arquivo CSV");
        fclose(arq_txt);
        return 1;
    }


    //Escreve o cabeçalho do CSV
    fprintf(arq_csv, "Data,Quantidade\n");

    //Processa cada Linha do arquivo TXT
    while (fgets(linha, sizeof(linha), arq_txt))
    {
        sscanf(linha, "%s %f", dados.data, &dados.quantidade);

        fprintf(arq_csv, "%s,%10.2f\n", dados.data, dados.quantidade);
    }
    

    fclose(arq_txt);
    fclose(arq_csv);
    
    printf("Convers�o conclu�da com sucesso!\n");

}


int main(int argc, char const *argv[]){

    setlocale(LC_ALL, "");
    //Ponteiro do arquivo

    converter_csv("dados.txt");
    
    
    return 0;
}

    
    

