#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

void maiusculo(char s1[], char s2[]){
    int i = 0;
    while (s1[i] != '\0'){
        s2[i] = toupper (s1[i]);
        i++;
    }
    s2[i] = '\0';
}

void minusculo(char s1[], char s2[]){
    int i = 0;
    while (s1[i] != '\0'){
        s2[i] = tolower (s1[i]);
        i++;
    }
    s2[i] = '\0';
}

char tamanho( char *nome){
    int count = 0;

    while (*nome != '\0' && count < 100){
        count ++;
        nome ++;
    }
    return count;
}

int contarVogais(char s1[]) {
    char vogais[] = "aeiouAEIOU";
    int numVogais = 0, i, j;

    for (i = 0; s1[i] != '\0'; i++) {
        for (j = 0; vogais[j] != '\0'; j++) {
            if (vogais[j] == s1[i]) {
                numVogais++;
                break;
            }
        }
    }

    return numVogais;
}

int contarConsoantes(char s1[]) {
    char consoantes[] = "bcdfghjklmnpqrstvxywzBCDFGHJKLMNPQRSTVWXYZ";
    int numConsoantes = 0, i, j;

    for (i = 0; s1[i] != '\0'; i++) {
        for (j = 0; consoantes[j] != '\0'; j++) {
            if (consoantes[j] == s1[i]) {
                numConsoantes++;
                break;
            }
        }
    }

    return numConsoantes;
}


int main() {
    char palavra[100];
    char armazem[200];
    int total;
    int total1;

    printf("Digite uma Palavra: ");
    fgets(palavra, sizeof(palavra),stdin);
    palavra[strcspn(palavra,"\n")] = '\0';


    printf("palavra original: %s\n",palavra);
    maiusculo(palavra, armazem);
    printf("palavra convertida de minuscula para maiuscula: %s\n", armazem);
    minusculo(palavra,armazem);
    printf("palavra convertida de maiuscula para minuscula: %s\n", armazem);
    printf("quantidade de caracters: %d\n", tamanho(palavra));
    total1 = contarConsoantes(palavra);
    printf("quantidade de consoante : %d\n",total1);
    total= contarVogais(palavra);
    printf("quantidade de vogais: %d\n", total);
    return 0;
}