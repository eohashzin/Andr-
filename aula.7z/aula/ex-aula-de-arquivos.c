#include <stdio.h>
#include <string.h>

int main(int argc, char const *argv[])
{
    int qtdFile = 0;
    while (qtdFile <= 10)
    {
        //Ponteiro do arquivo
        char nome_arquivo[50] = "arquivo";
        char numToString[10];
        sprintf(numToString,"%d", qtdFile);

        strcat(nome_arquivo, numToString);
        strcat(nome_arquivo, ".txt");
        FILE *arquivo;

        //Criei a porra do arquivo!
        arquivo = fopen(nome_arquivo, "w");

        //Foi aberto krlh?
        if (arquivo == NULL)
        {
            printf("Error para abrir o arquivo");
            return 1; // se deu erro não preciso continuar o execução
        }
        int a=0;
        while (a <= 100000000)
        {
            
        fprintf(arquivo, "Linha: %d \n", a);
        a++;
        }
        
        //quero escrever porra!

        //quero matar o arquivo!
        fclose(arquivo);
        qtdFile++;
    }
    
        
    

    return 0;
}
