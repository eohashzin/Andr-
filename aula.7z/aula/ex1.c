#include <stdio.h>
#include <locale.h>
#include <string.h>

#define MAX_TITULO 100
#define MAX_ATOR 50
#define MAX_VET 100

typedef struct {
    char titulo[MAX_TITULO];
    char autor[MAX_ATOR];
    int ano;  
}Livro;



void incluir(Livro biblioteca[], int *count){
    if (count < MAX_VET)
    {
        printf("\n Limite atingido!");
    }else{
    printf("\n Digite o Titulo do Livro: ");
    fflush(stdin);
    fgets(biblioteca[*count].titulo, sizeof(biblioteca[*count].titulo), stdin);
    printf("\n Digite o Autor do Livro: ");
    fflush(stdin);
    fgets(biblioteca[*count].autor, sizeof(biblioteca[*count].autor), stdin);
    printf("\n Digite o Ano do Livro: ");
    fflush(stdin);
    scanf("%d", &biblioteca[*count].ano);

    getchar();
    (*count)++;
    }
}

void listar(Livro biblioteca[], int count){
    for (int i = 0; i < count; i++)
    {
        printf("Titulo: %s \nAutor: %s \nAno: %d\n", biblioteca[i].titulo, biblioteca[i].autor, biblioteca[i].ano);
    }
    
}

void buscarTitulo(Livro *biblioteca, int count, char *tituloBusca){
    int encontrado = 0;
    for (int i = 0; i < count; i++)
    {
        if (strcmp( biblioteca[i].titulo, tituloBusca) == 0)
        {
            printf("Livro encontrado: ");
            printf("Titulo: %s \nAutor: %s \nAno: %d\n", biblioteca[i].titulo, biblioteca[i].autor, biblioteca[i].ano);
            encontrado = 1;
            break;
        }
        
    }
    if (!encontrado)
    {
        printf("Livro n�o Encontrado!");
    }

}

int main()
{
    Livro biblioteca[MAX_VET];
    setlocale(LC_ALL, "");
    int opcao, count = 0;
    char tituloBusca[MAX_TITULO];
    do
    {

        printf("\n Escolha uma Op��o: ");
        printf("\n 1 - Incluir um Livro ");
        printf("\n 2 - Listar Livros ");
        printf("\n 3 - Buscar por Titulo ");
        printf("\n 4 - Sair\n ");
        scanf("%d", &opcao);

        switch (opcao)
        {
        case 1:     
            incluir(biblioteca, &count);            
            break;
        case 2:
            listar(biblioteca, count);
            break;

        case 3: 
            printf("Qual � o titulo do livro: ");
            scanf("%s", tituloBusca);
            buscarTitulo(biblioteca, count, tituloBusca);
            break;

        case 4: 
            printf("Saindo...");
            break;

        default:
            printf("Op��o Invalida!");
            break;
        }
    } while (opcao != 4);
    

    return 0;
}

