#include <stdio.h>
#include <string.h>
#include <locale.h>
#define MAX_DISCIPLINA 8
#define MAX_ALUNOS 50

typedef struct {
    char nome[100];
    char email[200];
    float nota[MAX_DISCIPLINA];
}Estudantes;

void inserir(){
    Estudantes alunos[MAX_ALUNOS];
    fflush(stdin);
    for (int i = 0; i < sizeof(alunos); i++)
    {
        printf("Digite o nome Completo do Aluno: \n");
        fgets(alunos[i].nome, sizeof(alunos), stdin);
        fflush(stdin);
        printf("Digite o email do Aluno: \n");
        fgets(alunos[i].email, sizeof(alunos), stdin);
        fflush(stdin);
        printf("Digite a nota do Aluno nas Disciplinas: \n");
        for (int i = 0; i < MAX_DISCIPLINA; i++)
        {
            printf("Nota %d", i+1);
            scanf("%f", &alunos[i].nota);
        }
    }
    
    
    
    
}

int main(int argc, char const *argv[])
{
    setlocale(LC_ALL, "Portuguese");
    int opcao = -1;

    do
    {
        printf("Digite 1 para inserir um Aluno! \n");
        printf("Digite 2 para listar os Alunos! \n");
        printf("Digite 3 para Sair! \n");
        scanf("%d", &opcao);

        switch (opcao)
        {
        case 1:
            inserir();
            break;
        case 2:
            //;
            break;
        case 3:
            printf("Saindo...!");
            break;
            
        
        default:
            printf("Op��o Invalida!");
            break;
        }

    } while (opcao != 3);
    
    
    return 0;
}
