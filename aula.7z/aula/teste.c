#include <stdio.h>


int main(int argc, char const *argv[])
{
   for (int i = 0; i < 100; i++)
   {
    printf("Livro: %d\n", i+1);
   }
   
    

    return 0;
}
